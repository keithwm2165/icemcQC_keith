#!/bin/bash

# QC makes analysis plots using simulated data from icemc
#
# Created by Victoria Niu (niu.172@osu.edu) in April 2019
# This is part of my final project for class Physics 6810
#
# The previous version of plotter is on icemcQC GitHub (IcemcQCPlotter.sh)
# completed by Victoria Niu in summer 2018
#
#

# create the directory to stored the plot
PLOT_DIR = "%s\n"
ENG = "$@"
revision=output_anita3

if [ -d "$PLOT_DIR" ]
then
    echo $PLOT_DIR already exist
    rm -r $PLOT_DIR
    mkdir $PLOT_DIR
else
    mkdir $PLOT_DIR
fi

# compile the plotting program and run it
if [ "$PLOT_DIR"="Primaries" ]
then
    make -f M.read_Primaries
    ./read_Primaries $revision_$ENG/icefinal*
elif ["$PLOT_DIR"="trigger"]
then
    make -f M.read_trigger
    ./read_triggers $revision_$ENG/icefinal*
fi

echo make plots of $PLOT_DIR at energy $ENG





