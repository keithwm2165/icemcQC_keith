//
//
//Author: Victoria Niu
//Created Time: Summer 2018
//
//
//REVISED FROM THE SCRIPTS WRITTEN BY OINDREE BANERJEE, BRIAN CLARK AND PREVIOUS QC GROUP
//
// C++&Canvas Heading
#include <iostream>
#include <fstream>
#include <sstream>
#include <math.h>
#include <string>
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <time.h>
#include "TTreeIndex.h"
#include "TChain.h"
#include "TH1.h"
#include "TF1.h"
#include "TF2.h"
#include "TFile.h"
#include "TRandom.h"
#include "TRandom2.h"
#include "TRandom3.h"
#include "TTree.h"
#include "TLegend.h"
#include "TLine.h"
#include "TROOT.h"
#include "TPostScript.h"
#include "TCanvas.h"
#include "TH2F.h"
#include "TText.h"
#include "TProfile.h"
#include "TGraphErrors.h"
#include "TStyle.h"
#include "TMath.h"
#include <unistd.h>
#include "TVector3.h"
#include "TRotation.h"
#include "TSpline.h"
#include "Math/InterpolationTypes.h"
#include "Math/Interpolator.h"
#include "signal.h"
#include "icemc_random.h"

#include "TGaxis.h"
#include "TPaveStats.h"

// Icemc Headings
#include "Constants.h"
#include "Settings.h"
#include "position.hh"
#include "earthmodel.hh"
#include "Tools.h"
#include "vector.hh"
#include "roughness.hh"
#include "anita.hh"
#include "balloon.hh"
#include "icemodel.hh"
#include "Spectra.h"
#include "signal.hh"
#include "secondaries.hh"
#include "ray.hh"
#include "counting.hh"
#include "Primaries.h"
#include "Taumodel.hh"

using namespace std;

int NNU;
double RANDOMISEPOL;

////////////////PLOTTING SCRIPT FOR ICEMCQC WRITTEN BY VICTORIA NIU DURING SUMMER OF 2018, REVISED FROM THE SCRIPTS WRITTEN BY OINDREE BANERJEE, BRIAN CLARK AND PREVIOUS QC GROUP ///////////////////////////////

int main(int argc, char *argv[])
{
    gStyle->SetOptStat(1111);     // Setup Statistics;
    
    gStyle->SetFrameFillStyle (2);
    gStyle->SetFrameFillColor (0);
    gStyle->SetFrameLineColor (1);
    gStyle->SetFrameLineStyle (0);
    gStyle->SetFrameLineWidth (2.5);
    gStyle->SetFrameBorderSize(10);
    gStyle->SetFrameBorderMode(0);
    gStyle->SetHistLineWidth(2.5);
    gStyle->SetTitleFontSize(0.05);
    
    /*gStyle->SetHistFillColor(0);
    gStyle->SetHistFillStyle(1);
    gStyle->SetHistLineColor(1);
    gStyle->SetHistLineStyle(0);
    gStyle->SetHistLineWidth(3);       //Setup plot Style */
    
    
    if(argc<2)
    {
        cout << "Not enough arguments! Stop run. " << endl;
    }
    
    TH2D *posnu_xy = new TH2D("posnu_xy","posnu xy", 200, -3000, 4000, 200, -2500, 2500);
    TH1F *altitude_hist = new TH1F("altitude_in", "", 45,-2500,100);
    TH1F *r_fromballoon_hist = new TH1F("r_fromballoon", "", 40, 0, 800);
    TH1F *nuflavorint_hist = new TH1F("nuflavorint", "",3,.5,3.5);
    TH1D *r_fromballoon_sq_hist = new TH1D("r_fromballoon_sq", "; r_fromballoon_sq; counts", 50, -100, 5e5);
    TH2D *r_fromballoon_vs_depth_int = new TH2D("r_fromballoon_vs_depth_int", "; r_fromballoon; depth_int", 200, 0, 7e2, 200, -3500, 0);
    TH2D *r_fromballoon_sq_vs_depth_int = new TH2D("r_fromballoon_sq_vs_depth_int", "; r_fromballoon_sq; depth_int", 200, 0, 5e5, 200, -3500, 0);
    TH1D *fresnel_1 = new TH1D("fresnel1", "; fresnel1; counts", 45, 0.98, 1.001);
    TH1D *fresnel_2 = new TH1D("fresnel2", "; fresnel2; counts", 45, 0.1, 1.05);
    TH1F *currentint_hist = new TH1F("currentint", "", 2, -0.2, 1.4);
    TH1F *dtrying_hist = new TH1F("dtryingdirection", "", 30, 0.95, 1.1);
    TH1F *chord_kgm2_bestcase_hist = new TH1F("chord_kgm2_bestcase","", 30, -100, 3.5e3);
    TH1F *weight_bestcase_hist = new TH1F("weight_bestcase", "",40,-0.1,1);
    TH1F *logchord_hist = new TH1F("logchord", "", 40, 1, 8);
    TH1F *r_exit2bn_hist = new TH1F("r_exit2bn","",40,0,700);
    TH1F *r_exit2bn_measured_hist = new TH1F("r_exit2bn_measured", "", 50, 0, 500);
    TH1F *nuexit_hist = new TH1F("nuexit", "",45,-1e2, 600);
    TH1F *nuexitice_hist = new TH1F("nuexitice", "",40, 6356, 6363);
    TH1F *costheta_nutraject_hist = new TH1F("cos(theta)", "", 40, -0.2, 0.2);
    TH1F *d1_hist = new TH1F("d1","",35,-150,2.3e3);
    TH1F *d2_hist = new TH1F("d2","",30,-100,600);
    TH1F *d1plusd2_hist = new TH1F("d1+d2","",35,-100,2.2e3);
    // TH2D *nnu_hist = new TH2D("nnu", "; nnu[0]; nnu[1]", 150, -2, 2, 150, -2, 2);
    TH1D *theta_hist = new TH1D("theta", "; theta; counts", 40, 0, 100);
    TH1D *r_in_hist = new TH1D("r_in","; r_in; counts",55,6355,6390);
    TH1D *r_enterice_hist = new TH1D("r_enterice","; r_enterice; counts",45,6320,6370);
    TH1D *chord_hist = new TH1D("chord","; chord; counts",35,-150,2.3e3);
    TH1D *dviewangle_deg_hist = new TH1D("dviewangle_deg", "; dviewangle_deg; counts", 50, -15, 10);
    TH1D *n_exit_phi_hist = new TH1D("n_exit_phi", "; n_exit_phi; counts", 50, 0, 360);
    TH1D *mytheta_hist = new TH1D("mytheta", "; mytheta; counts", 40, -0.5, 9.0);
    TH1D *mybeta_hist = new TH1D("mybeta", "; mybeta; counts", 40, -10, 4);
    TH1D *theta_rf_atbn_hist = new TH1D("theta_rf_atbn", "; theta_rf_atbn; counts", 40, 40, 70);
    TH1F *nnucostheta_hist = new TH1F("nnucostheta", "", 30, -0.6, 1.4);
    TH1F *nnuphi_hist = new TH1F("nnuphi", "", 30, -0.5, 7);
    TH1F *rincostheta_hist = new TH1F("rin_costheta", "", 35, 0.2, 1.04);
    TH1F *rinphi_hist = new TH1F("rin_phi", "", 40, 0, 6.3);
    TH2D *theta_vs_phi_hist = new TH2D("theta_vs_phi", "; theta; phi", 100, 0, 180, 100, 0, 0.000001);
    
    posnu_xy->SetTitle("location of interaction (ANITA loops around Antarctica)");
    posnu_xy->GetXaxis()->SetTitle("X Coordinate (km)"); //set the x-axis title
    posnu_xy->GetXaxis()->SetTitleOffset(1.2);
    posnu_xy->GetXaxis()->CenterTitle();
    posnu_xy->GetYaxis()->SetTitle("Y Coordinate (km)"); //set the y-axis title
    posnu_xy->GetYaxis()->SetTitleOffset(1.2);
    posnu_xy->GetYaxis()->CenterTitle();
    
    // altitude_hist->SetTitle("Depth of Interactions");
    altitude_hist->GetXaxis()->SetTitle("depth of interactions (m)");
    altitude_hist->GetXaxis()->SetTitleOffset(1.2);
    // altitude_hist->SetTitleSize(0.2, "xy");
    altitude_hist->GetXaxis()->CenterTitle();
    altitude_hist->GetYaxis()->SetTitle("weighted event number");
    altitude_hist->GetYaxis()->SetTitleOffset(1.2);
    altitude_hist->GetYaxis()->CenterTitle();
    
    // r_fromballoon_hist->SetTitle("Surface Distance of Interaction from Balloon");
    r_fromballoon_hist->GetXaxis()->SetTitle("surface distance of interaction point (km)");
    r_fromballoon_hist->GetXaxis()->CenterTitle();
    r_fromballoon_hist->GetYaxis()->SetTitle("weighted event number");
    r_fromballoon_hist->GetYaxis()->CenterTitle();
    
    // nuflavorint_hist->SetTitle("Neutrino Flavors");
    nuflavorint_hist->GetXaxis()->SetTitle("neutrino flavor (1=electron, 2=muon, 3=tau)");
    nuflavorint_hist->GetYaxis()->SetTitle("weighted event number");
    nuflavorint_hist->GetXaxis()->SetTitleOffset(1.2);
    nuflavorint_hist->GetYaxis()->SetTitleOffset(1.5);
    nuflavorint_hist->GetXaxis()->CenterTitle();
    nuflavorint_hist->GetYaxis()->CenterTitle();
    
    // r_fromballoon_sq_hist->SetTitle("Surface Distance Squared of Interaction from Balloon");
    r_fromballoon_sq_hist->GetXaxis()->SetTitle("surface distance squared of interaction point (km^2)");
    r_fromballoon_sq_hist->GetXaxis()->CenterTitle();
    r_fromballoon_sq_hist->GetYaxis()->SetTitle("weighted events number");
    r_fromballoon_sq_hist->GetYaxis()->CenterTitle();
    
    // r_fromballoon_vs_depth_int->SetTitle("Surface Distance vs Depth of Interaction");
    r_fromballoon_vs_depth_int->GetXaxis()->SetTitle("surface distance of interaction point (km)");
    r_fromballoon_vs_depth_int->GetXaxis()->SetTitleOffset(1.2);
    r_fromballoon_vs_depth_int->GetXaxis()->CenterTitle();
    r_fromballoon_vs_depth_int->GetYaxis()->SetTitle("depth of interactions (m)");
    r_fromballoon_vs_depth_int->GetYaxis()->SetTitleOffset(1.6);
    r_fromballoon_vs_depth_int->GetYaxis()->CenterTitle();
    
    r_fromballoon_sq_vs_depth_int->GetXaxis()->SetTitle("surface distance squared of interaction point (km)");
    r_fromballoon_sq_vs_depth_int->GetXaxis()->SetTitleOffset(1.2);
    r_fromballoon_sq_vs_depth_int->GetXaxis()->CenterTitle();
    r_fromballoon_sq_vs_depth_int->GetYaxis()->SetTitle("depth of interactions (m)");
    r_fromballoon_sq_vs_depth_int->GetYaxis()->SetTitleOffset(1.6);
    r_fromballoon_sq_vs_depth_int->GetYaxis()->CenterTitle();
    // r_fromballoon_sq_vs_depth_int->SetTitle("Surface Distance Squared of Interaction from Balloon vs Depth");
    
    // fresnel_1->SetTitle("Fresnel Coefficient at Air-Firn Interface");
    fresnel_1->GetXaxis()->SetTitle("net fresnel factor on field at ice-firn interface");
    fresnel_1->GetXaxis()->SetTitleOffset(1.2);
    fresnel_1->GetXaxis()->CenterTitle();
    fresnel_1->GetYaxis()->SetTitle("weighted events number");
    fresnel_1->GetYaxis()->SetTitleOffset(1.2);
    fresnel_1->GetYaxis()->CenterTitle();
    
    // fresnel_2->SetTitle("Fresnel Coefficient at Air-Firn Interface");
    fresnel_2->GetXaxis()->SetTitle("net fresnel factor on field at firn-air interface");
    fresnel_2->GetXaxis()->SetTitleOffset(1.2);
    fresnel_2->GetXaxis()->CenterTitle();
    fresnel_2->GetYaxis()->SetTitle("weighted events number");
    fresnel_2->GetYaxis()->SetTitleOffset(1.2);
    fresnel_2->GetYaxis()->CenterTitle();
    
    // currentint_hist->SetTitle("The Charge of Neutrinos");
    currentint_hist->GetXaxis()->SetTitle("charge of neutrino: 0 is neutral, 1 is charged");
    currentint_hist->GetXaxis()->SetTitleOffset(1.2);
    currentint_hist->GetXaxis()->CenterTitle();
    currentint_hist->GetYaxis()->SetTitle("weighted events number");
    currentint_hist->GetYaxis()->SetTitleOffset(1.5);
    currentint_hist->GetYaxis()->CenterTitle();
    
    dtrying_hist->SetTitle("*that each neutrino counts for after having reduced angular phase space for possibly-detectable events");
    dtrying_hist->GetXaxis()->SetTitle("weighting factor: number of equivalent tries*");
    dtrying_hist->GetXaxis()->SetTitleOffset(1.2);
    dtrying_hist->GetXaxis()->CenterTitle();
    dtrying_hist->GetYaxis()->SetTitle("weighted events number");
    dtrying_hist->GetYaxis()->SetTitleOffset(1.5);
    dtrying_hist->GetYaxis()->CenterTitle();
    
    // chord_kgm2_bestcase_hist->SetTitle("Traverse Chord Length (if neutrino all was crust density)");
    chord_kgm2_bestcase_hist->GetXaxis()->SetTitle("chord-length(1000 km) that neutrino would traverse if it was crust density");
    chord_kgm2_bestcase_hist->GetXaxis()->SetTitleOffset(1.2);
    chord_kgm2_bestcase_hist->GetXaxis()->CenterTitle();
    chord_kgm2_bestcase_hist->GetYaxis()->SetTitle("weighted events number");
    chord_kgm2_bestcase_hist->GetYaxis()->SetTitleOffset(1.2);
    chord_kgm2_bestcase_hist->GetYaxis()->CenterTitle();
    
    // weight_bestcase_hist->SetTitle("Best Case Weight");
    weight_bestcase_hist->GetXaxis()->SetTitle("the weight of events if whole earth had density of crust");
    weight_bestcase_hist->GetXaxis()->SetTitleOffset(1.2);
    weight_bestcase_hist->GetXaxis()->CenterTitle();
    weight_bestcase_hist->GetYaxis()->SetTitle("weighted events number");
    weight_bestcase_hist->GetYaxis()->SetTitleOffset(1.2);
    weight_bestcase_hist->GetYaxis()->CenterTitle();
    
    // logchord_hist->SetTitle("Log of Chord Length");
    logchord_hist->GetXaxis()->SetTitle("log_10 of chord-length(m) from earth entrance to rock-ice boundary");
    logchord_hist->GetXaxis()->SetTitleOffset(1.2);
    logchord_hist->GetXaxis()->CenterTitle();
    logchord_hist->GetYaxis()->SetTitle("weighted events number");
    logchord_hist->GetYaxis()->SetTitleOffset(1.2);
    logchord_hist->GetYaxis()->CenterTitle();
    
    // r_exit2bn_hist->SetTitle("Surface Distance of Neutrino When Exiting Balloon");
    r_exit2bn_hist->GetXaxis()->SetTitle("predicted surface distance where neutrino exits the balloon (km)");
    r_exit2bn_hist->GetXaxis()->SetTitleOffset(1.2);
    r_exit2bn_hist->GetXaxis()->CenterTitle();
    r_exit2bn_hist->GetYaxis()->SetTitle("weighted events number");
    r_exit2bn_hist->GetYaxis()->SetTitleOffset(1.2);
    r_exit2bn_hist->GetYaxis()->CenterTitle();
    
    // r_exit2bn_measured_hist->SetTitle("Measured Surface Distance of Neutrino When Exiting Balloon");
    r_exit2bn_measured_hist->GetXaxis()->SetTitle("measured surface distance where neutrino exits the balloon (km)");
    r_exit2bn_measured_hist->GetXaxis()->SetTitleOffset(1.2);
    r_exit2bn_measured_hist->GetXaxis()->CenterTitle();
    r_exit2bn_measured_hist->GetYaxis()->SetTitle("weighted events number");
    r_exit2bn_measured_hist->GetYaxis()->SetTitleOffset(1.2);
    r_exit2bn_measured_hist->GetYaxis()->CenterTitle();

    // nuexit_hist->SetTitle("Neutrinos Exit the Earth");
    nuexit_hist->GetXaxis()->SetTitle("distance where neutrino would have left the earth to the earth center (km)");
    nuexit_hist->GetXaxis()->SetTitleOffset(1.2);
    nuexit_hist->GetXaxis()->CenterTitle();
    nuexit_hist->GetYaxis()->SetTitle("weighted events number");
    nuexit_hist->GetYaxis()->SetTitleOffset(1.2);
    nuexit_hist->GetYaxis()->CenterTitle();
    
    // nuexitice_hist->SetTitle("Neutrinos Exit the Ice");
    nuexitice_hist->GetXaxis()->SetTitle("distance where neutrino would have left the ice to the earth center (km)");
    nuexitice_hist->GetXaxis()->SetTitleOffset(1.0);
    nuexitice_hist->GetXaxis()->CenterTitle();
    nuexitice_hist->GetYaxis()->SetTitle("weighted events number");
    nuexitice_hist->GetYaxis()->SetTitleOffset(1.5);
    nuexitice_hist->GetYaxis()->CenterTitle();
    
    costheta_nutraject_hist->SetTitle("*theta angle of neutrino interacting direction from earth center to balloon (spherical coordinate)");
    costheta_nutraject_hist->GetXaxis()->SetTitle("cos(theta*)");
    costheta_nutraject_hist->GetXaxis()->SetTitleOffset(1.2);
    costheta_nutraject_hist->GetXaxis()->CenterTitle();
    costheta_nutraject_hist->GetYaxis()->SetTitle("weighted events number");
    costheta_nutraject_hist->GetYaxis()->SetTitleOffset(1.2);
    costheta_nutraject_hist->GetYaxis()->CenterTitle();
    
    // d1_hist->SetTitle("d1: Earth Entrance to Rock-Ice Boundary");
    d1_hist->GetXaxis()->SetTitle("distance from earth entrance to rock-ice boundary (km)");
    d1_hist->GetXaxis()->SetTitleOffset(1.2);
    d1_hist->GetXaxis()->CenterTitle();
    d1_hist->GetYaxis()->SetTitle("weighted events number");
    d1_hist->GetYaxis()->SetTitleOffset(1.2);
    d1_hist->GetYaxis()->CenterTitle();
    
    // d2_hist->SetTitle("distance from ice-rock Boundary to interaction point (km)");
    d2_hist->GetXaxis()->SetTitle("distance from ice-rock Boundary to interaction point (km)");
    d2_hist->GetXaxis()->SetTitleOffset(1.2);
    d2_hist->GetXaxis()->CenterTitle();
    d2_hist->GetYaxis()->SetTitle("weighted events number");
    d2_hist->GetYaxis()->SetTitleOffset(1.2);
    d2_hist->GetYaxis()->CenterTitle();
    
    // d1plusd2_hist->SetTitle("Earth Entrance to Interaction Point");
    d1plusd2_hist->GetXaxis()->SetTitle("distance from earth entrance to interaction point (km)");
    d1plusd2_hist->GetXaxis()->SetTitleOffset(1.2);
    d1plusd2_hist->GetXaxis()->CenterTitle();
    d1plusd2_hist->GetYaxis()->SetTitle("weighted events number");
    d1plusd2_hist->GetYaxis()->SetTitleOffset(1.2);
    d1plusd2_hist->GetYaxis()->CenterTitle();
    
    // nnu_hist->SetTitle("Direction of Neutrinos(+z in south pole direction)");
    // nnu_hist->GetXaxis()->SetTitle("X Coordinate(m)");
    // nnu_hist->GetXaxis()->SetTitleOffset(1.0);
    // nnu_hist->GetXaxis()->CenterTitle();
    // nnu_hist->GetYaxis()->SetTitle("Y Coordinate(m)");
    // nnu_hist->GetYaxis()->SetTitleOffset(1.5);
    // nnu_hist->GetYaxis()->CenterTitle();
    
    // theta_hist->SetTitle("Interaction Angle (Theta)");
    theta_hist->GetXaxis()->SetTitle("theta (deg) of neutrino interacting direction from earth center to balloon as z axis ");
    theta_hist->GetXaxis()->SetTitleOffset(1.2);
    theta_hist->GetXaxis()->CenterTitle();
    theta_hist->GetYaxis()->SetTitle("weighted events number");
    theta_hist->GetYaxis()->SetTitleOffset(1.2);
    theta_hist->GetYaxis()->CenterTitle();
    
    // r_in_hist->SetTitle("Position(Magnitude) where Neutrino Enters the Earth");
    r_in_hist->GetXaxis()->SetTitle("distance to the earth center where neutrino enters the earth (km)");
    r_in_hist->GetXaxis()->SetTitleOffset(1.2);
    r_in_hist->GetXaxis()->CenterTitle();
    r_in_hist->GetYaxis()->SetTitle("weighted events number");
    r_in_hist->GetYaxis()->SetTitleOffset(1.2);
    r_in_hist->GetYaxis()->CenterTitle();
    
    // r_enterice_hist->SetTitle("Position where Neutrino Enters the Ice");
    r_enterice_hist->GetXaxis()->SetTitle("distance to the earth center where neutrino enters the ice (km)");
    r_enterice_hist->GetXaxis()->SetTitleOffset(1.2);
    r_enterice_hist->GetXaxis()->CenterTitle();
    r_enterice_hist->GetYaxis()->SetTitle("weighted events number");
    r_enterice_hist->GetYaxis()->SetTitleOffset(1.2);
    r_enterice_hist->GetYaxis()->CenterTitle();
    
    // chord_hist->SetTitle("Chord from Earth Entrance to Rock-Ice Boundary");
    chord_hist->GetXaxis()->SetTitle("chord-length from earth entrance to rock-ice boundary (km)");
    chord_hist->GetXaxis()->SetTitleOffset(1.2);
    chord_hist->GetXaxis()->CenterTitle();
    chord_hist->GetYaxis()->SetTitle("weighted events number");
    chord_hist->GetYaxis()->SetTitleOffset(1.2);
    chord_hist->GetYaxis()->CenterTitle();
    
    // dviewangle_deg_hist->SetTitle("Deviation from the Cerenkov Angle");
    dviewangle_deg_hist->GetXaxis()->SetTitle("deviation from the cerenkov angle (deg)");
    dviewangle_deg_hist->GetXaxis()->SetTitleOffset(1.2);
    dviewangle_deg_hist->GetXaxis()->CenterTitle();
    dviewangle_deg_hist->GetYaxis()->SetTitle("weighted events number");
    dviewangle_deg_hist->GetYaxis()->SetTitleOffset(1.2);
    dviewangle_deg_hist->GetYaxis()->CenterTitle();
    
    // n_exit_phi_hist->SetTitle("Phi Angle of the Ray from the Surface to the Balloon");
    n_exit_phi_hist->GetXaxis()->SetTitle("phi angle (deg) of the ray from the surface to balloon (spherical coordinate)");
    n_exit_phi_hist->GetXaxis()->SetTitleOffset(1.0);
    n_exit_phi_hist->GetXaxis()->CenterTitle();
    n_exit_phi_hist->GetYaxis()->SetTitle("weighted events number");
    n_exit_phi_hist->GetYaxis()->SetTitleOffset(1.5);
    n_exit_phi_hist->GetYaxis()->CenterTitle();
    
    mytheta_hist->SetTitle("*alpha = angle between neutrino momentum and surface normal at earth entrance point");
    mytheta_hist->GetXaxis()->SetTitle("alpha angle* minus 90 degrees");
    mytheta_hist->GetXaxis()->SetTitleOffset(1.2);
    mytheta_hist->GetXaxis()->CenterTitle();
    mytheta_hist->GetYaxis()->SetTitle("weighted events number");
    mytheta_hist->GetYaxis()->SetTitleOffset(1.2);
    mytheta_hist->GetYaxis()->CenterTitle();
    
    mybeta_hist->SetTitle("*beta = angle wrt the horizontal that the ray hits the balloon");
    mybeta_hist->GetXaxis()->SetTitle("beta angle* minus 90 degrees ");
    mybeta_hist->GetXaxis()->SetTitleOffset(1.2);
    mybeta_hist->GetXaxis()->CenterTitle();
    mybeta_hist->GetYaxis()->SetTitle("weighted events number");
    mybeta_hist->GetYaxis()->SetTitleOffset(1.2);
    mybeta_hist->GetYaxis()->CenterTitle();
    
    // theta_rf_atbn_hist->SetTitle("Polar Angle of the Signal seen by Perfect Eyes at the Balloon");
    theta_rf_atbn_hist->GetXaxis()->SetTitle("polar angle (deg) of the signal as seen by perfect eyes at the balloon");
    theta_rf_atbn_hist->GetXaxis()->SetTitleOffset(1.2);
    theta_rf_atbn_hist->GetXaxis()->CenterTitle();
    theta_rf_atbn_hist->GetYaxis()->SetTitle("weighted events number");
    theta_rf_atbn_hist->GetYaxis()->SetTitleOffset(1.2);
    theta_rf_atbn_hist->GetYaxis()->CenterTitle();
    
    // nnucostheta_hist->SetTitle("NNU Cos(Theta)");
    nnucostheta_hist->GetXaxis()->SetTitle("cos(theta) of neutrino direction when interacting (spherical coordinate)");
    nnucostheta_hist->GetXaxis()->SetTitleOffset(1.2);
    nnucostheta_hist->GetXaxis()->CenterTitle();
    nnucostheta_hist->GetYaxis()->SetTitle("weighted events number");
    nnucostheta_hist->GetYaxis()->SetTitleOffset(1.5);
    nnucostheta_hist->GetYaxis()->CenterTitle();
    
    // nnuphi_hist->SetTitle("NNU Phi");
    nnuphi_hist->GetXaxis()->SetTitle("phi angle (deg) of neutrino direction when interacting (spherical coordinate)");
    nnuphi_hist->GetXaxis()->SetTitleOffset(1.2);
    nnuphi_hist->GetXaxis()->CenterTitle();
    nnuphi_hist->GetYaxis()->SetTitle("weighted events number");
    nnuphi_hist->GetYaxis()->SetTitleOffset(1.5);
    nnuphi_hist->GetYaxis()->CenterTitle();
    
    
    rincostheta_hist->SetTitle("*theta angle of neutrino direction when entering the earth (spherical coordinate)");
    rincostheta_hist->GetXaxis()->SetTitle("cos(theta*)");
    rincostheta_hist->GetXaxis()->SetTitleOffset(1.2);
    rincostheta_hist->GetXaxis()->CenterTitle();
    rincostheta_hist->GetYaxis()->SetTitle("weighted events number");
    rincostheta_hist->GetYaxis()->SetTitleOffset(1.2);
    rincostheta_hist->GetYaxis()->CenterTitle();
    
    
    rinphi_hist->SetTitle("*phi angle of neutrino direction when entering the earth (spherical coordinate)");
    rinphi_hist->GetXaxis()->SetTitle("phi*");
    rinphi_hist->GetXaxis()->SetTitleOffset(1.2);
    rinphi_hist->GetXaxis()->CenterTitle();
    rinphi_hist->GetYaxis()->SetTitle("weighted events number");
    rinphi_hist->GetYaxis()->SetTitleOffset(1.2);
    rinphi_hist->GetYaxis()->CenterTitle();
    
    theta_vs_phi_hist->SetTitle("Theta vs Phi");
    theta_vs_phi_hist->GetXaxis()->SetTitle("theta");
    theta_vs_phi_hist->GetXaxis()->SetTitleOffset(1.0);
    theta_vs_phi_hist->GetXaxis()->CenterTitle();
    theta_vs_phi_hist->GetYaxis()->SetTitle("Phi");
    theta_vs_phi_hist->GetYaxis()->SetTitleOffset(1.5);
    theta_vs_phi_hist->GetYaxis()->CenterTitle();
    
    
    for(int i=1; i < argc; i++)
        
    {  // loop over the input files
        
        string readfile = string(argv[i]);
        TFile *AnitaFile = new TFile(( readfile ).c_str());
        cout << "AnitaFile" << endl;
        TTree *passing_events = (TTree*)AnitaFile->Get("passing_events");
        cout << "Reading AnitaFile..." << endl;
        cout << "num: " << readfile << endl;
        
        int const kilometer = 1000; // transform m to km
        int num_pass;               // number of entries (ultra-neutrinos);
        double weight;              // weight of neutrino counts;
        double nnu[3];              // trajectory of neutrinos;
        double posnu[3];            // position of interaction;
        double depth_int;           // depth of interaction;
        
        double costheta_nutraject;  // the interaction angle theta;
        double phi_nutraject;       // the interaction angle phi;
        double theta;               // arccos of costheta_nutraject in degrees;
        double phi;                 // phi_nutraject in degrees;
        double mybeta;              // beta angle minus 90 degrees;
        double mytheta;             // alpha angle minus 90 degrees;
        double theta_rf_atbn;       // polar angle of the signal viewed at the Balloon;
        double nnucostheta;         // costheta of the neutrino trajectory;
        double nnuphi;              // phi of the neutrino trajectory;
        double rincostheta;         // costheta at the entrance;
        double rinphi;              // phi at the entrance;
        
        double r_in[3];             // position of neurtinos when entering the balloon;
        double rin;                 // the magnitude of r_in;
        double r_enterice[3];       // position of neurtinos when entering the ice;
        double r_enterice2;         // position of neurtinos when entering the ice (km);
        double renterice;           // the magnitude of renterice;
        double nuexit;              // position where neutrino would have exit;
        double nuexit2;             // position where neutrino would have exit (km);
        double nuexitice;           // position where neutrino would have left the ice;
        double nuexitice2;          // position where neutrino would have left the ice (km);
        double n_exit_phi;          // phi when neutrino exits;
        double r_exit2bn;           // surfance distance when neutrino exits the balloon;
        double r_exit2bn2;          // surfance distance when neutrino exits the balloon (km);
        double r_exit2bn_measured;  // measured surface distance when neutrino exits the balloon;
        double r_exit2bn_measured2; // measured surface distance when neutrino exits the balloon (km);
        double r_fromballoon;       // Surface distance of interaction from the balloon;
        double r_fromballoon2;      // Surface distance of interaction from the balloon (km);
        double r_fromballoon_sq;    // r_fromballoon squared
        double r_fromballoon_sq2;   // Surface distance of interaction from the balloon (km^2);
        
        
        double d1;                   // Distance from Earth entrance to rock-ice boundary
        double d12;                  // Distance from Earth entrance to rock-ice boundary (km)
        double d2;                   // Distance from Rock-ice boundary to interaction point
        double d22;                  // Distance from Rock-ice boundary to interaction point (km)
        double d1plusd2;             // Distance from Earth Entrance to Interaction Point
        double d1plusd22;            // Distance from Earth Entrance to Interaction Point(km)
        int currentint;              // the charge of neurtinos;
        
        
        double chord;                 // chord length of neutrino;
        double chord2;                // chord length of neutrino (km);
        double logchord;              // log_10 of chord length;
        double weight_bestcase;       // best case weight (when all densities equal to Earth crust;
        double chord_kgm2_bestcase;   // chord at bestcase weight;
        double chord_kgm2_bestcase2;  // chord at bestcase weight(km);
        double dtryingdirection;      // weight factor;
        
        int nuflavorint;              // neutrino flavors;
        double fresnel1;              // Fresnel coefficient;
        double fresnel2;              // Fresnel coefficient;
        double dviewangle_deg;        // deviation from the cerenkov angle;
        
        num_pass = passing_events->GetEntries();
        cout << "num_pass is " << num_pass << endl;
        
        /*PRIMARIES VARIABLES*/
        passing_events->SetBranchAddress("nnu", &nnu);
        passing_events->SetBranchAddress("costheta_nutraject", &costheta_nutraject);
        passing_events->SetBranchAddress("phi_nutraject", &phi_nutraject);
        passing_events->SetBranchAddress("weight", &weight);
        passing_events->SetBranchAddress("r_in", &r_in);
        passing_events->SetBranchAddress("r_enterice", &r_enterice);
        passing_events->SetBranchAddress("nuexitlength", &nuexit);
        passing_events->SetBranchAddress("d1", &d1);
        passing_events->SetBranchAddress("d2", &d2);
        passing_events->SetBranchAddress("current", &currentint);
        passing_events->SetBranchAddress("altitude_int", &depth_int);
        passing_events->SetBranchAddress("r_fromballoon", &r_fromballoon);
        passing_events->SetBranchAddress("r_exit2bn", &r_exit2bn);
        passing_events->SetBranchAddress("r_exit2bn_measured", &r_exit2bn_measured);
        passing_events->SetBranchAddress("nuflavor", &nuflavorint);
        passing_events->SetBranchAddress("posnu", &posnu);
        passing_events ->SetBranchAddress("chord",&chord);
        passing_events->SetBranchAddress("logchord", &logchord);
        passing_events->SetBranchAddress("nuexitice", &nuexitice);
        passing_events->SetBranchAddress("weight_bestcase", &weight_bestcase);
        passing_events->SetBranchAddress("chord_kgm2_bestcase", &chord_kgm2_bestcase);
        passing_events->SetBranchAddress("dtryingdirection", &dtryingdirection);
        passing_events ->SetBranchAddress("dviewangle_deg",&dviewangle_deg);
        passing_events ->SetBranchAddress("fresnel1",&fresnel1);
        passing_events ->SetBranchAddress("fresnel2",&fresnel2);
        passing_events ->SetBranchAddress("mytheta",&mytheta);
        passing_events ->SetBranchAddress("mybeta",&mybeta);
        passing_events ->SetBranchAddress("theta_rf_atbn",&theta_rf_atbn);
        passing_events ->SetBranchAddress("n_exit_phi",&n_exit_phi);
        
        cout << endl;
    
        for (int k=0; k <=num_pass; k++)
        {
            
            r_fromballoon_sq=r_fromballoon*r_fromballoon;
            d1plusd2=d1+d2;
            theta=acos(costheta_nutraject)*180.0/3.14;
            rin=sqrt(r_in[0]*r_in[0]+r_in[1]*r_in[1]+r_in[2]*r_in[2])/kilometer;
            renterice=sqrt(r_enterice[0]*r_enterice[0]+r_enterice[1]*r_enterice[1]+r_enterice[2]*r_enterice[2]);
            nnucostheta=nnu[2]/(sqrt(nnu[0]*nnu[0]+nnu[1]*nnu[1]+nnu[2]*nnu[2]));
            nnuphi=atan2(nnu[1],nnu[0]);
            chord_kgm2_bestcase2 = chord_kgm2_bestcase/1000000;
            chord2 = chord/kilometer;
            d12 = d1/kilometer;
            d1plusd22 = d1plusd2/kilometer;
            d22 = d2/kilometer;
            nuexit2 = nuexit/kilometer;
            nuexitice2 = nuexitice/kilometer;
            r_enterice2 = renterice/kilometer;
            r_exit2bn_measured2 = r_exit2bn_measured/kilometer;
            r_exit2bn2 = r_exit2bn/kilometer;
            r_fromballoon2 = r_fromballoon/kilometer;
            r_fromballoon_sq2 = r_fromballoon_sq/1000000;
            
            if (nnuphi<0)
            {
                nnuphi=nnuphi+2*PI;
            }
            rincostheta=r_in[2]/(sqrt(r_in[0]*r_in[0]+r_in[1]*r_in[1]+r_in[2]*r_in[2]));
            rinphi=atan2(r_in[1],r_in[0]);
            if (rinphi<0)
            {
                rinphi=rinphi+2*PI;
            }
            phi = phi_nutraject * 57.3;
            
            passing_events->GetEvent(k);
            
            posnu_xy -> Fill(posnu[0]/1000, posnu[1]/1000,weight);
            altitude_hist->Fill(depth_int, weight);
            r_fromballoon_hist->Fill(r_fromballoon2, weight);
            nuflavorint_hist->Fill(nuflavorint, weight);
            r_fromballoon_hist->Fill(r_fromballoon2, weight);
            r_fromballoon_sq_hist->Fill(r_fromballoon_sq2, weight);
            r_fromballoon_vs_depth_int->Fill(r_fromballoon2,depth_int,weight);
            r_fromballoon_sq_vs_depth_int->Fill(r_fromballoon_sq2,depth_int,weight);
            fresnel_1->Fill(fresnel1, weight);
            fresnel_2->Fill(fresnel2, weight);
            currentint_hist->Fill(currentint, weight);
            dtrying_hist->Fill(dtryingdirection, weight);
            chord_kgm2_bestcase_hist->Fill(chord_kgm2_bestcase2, weight);
            weight_bestcase_hist->Fill(weight_bestcase, weight);
            logchord_hist->Fill(logchord, weight);
            r_exit2bn_hist->Fill(r_exit2bn2, weight);
            r_exit2bn_measured_hist->Fill(r_exit2bn_measured2, weight);
            nuexit_hist->Fill(nuexit2, weight);
            nuexitice_hist->Fill(nuexitice2, weight);
            costheta_nutraject_hist->Fill(costheta_nutraject, weight);
            d1_hist->Fill(d12, weight);
            d2_hist->Fill(d22, weight);
            d1plusd2_hist->Fill(d1plusd22, weight);
            // nnu_hist->Fill(nnu[0],nnu[1],weight);
            theta_hist->Fill(theta,weight);
            r_in_hist->Fill(rin,weight);
            chord_hist->Fill(chord2,weight);
            r_enterice_hist->Fill(r_enterice2,weight);
            dviewangle_deg_hist->Fill(dviewangle_deg,weight);
            n_exit_phi_hist->Fill(n_exit_phi,weight);
            mytheta_hist->Fill(mytheta,weight);
            mybeta_hist->Fill(mybeta,weight);
            theta_rf_atbn_hist->Fill(theta_rf_atbn*57.295779513, weight);
            nnucostheta_hist->Fill(nnucostheta,weight);
            nnuphi_hist->Fill(nnuphi,weight);
            rincostheta_hist->Fill(rincostheta, weight);
            rinphi_hist->Fill(rinphi, weight);
            theta_vs_phi_hist->Fill(theta,phi,weight);
            
            
        }               // CLOSE FOR LOOP OVER NUMBER OF EVENTS
        
    } // CLOSE FOR LOOP OVER NUMBER OF INPUT FILES
            
    //  Make Histograms
    
    // c1.Positions of Interactions Histogram (posnu)
    TCanvas *c1 = new TCanvas("c1","Location",1100,850); //make a square canvas
    gStyle->SetOptTitle(1);
    gStyle->SetStatX(0.90);
    gStyle->SetStatY(0.90);
    posnu_xy->Draw("colz");
    
    gStyle->SetHistLineWidth(9);
    c1->SaveAs("Primaries/posnu_xy.png");
    gStyle->SetHistLineWidth(2);
    c1->SaveAs("Primaries/posnu_xy.pdf");
    c1->SaveAs("Primaries/posnu_xy.root");
    
    
    //c2.Depth of Interaction Histogram (depth_int) *altitude_hist is depth_int
    TCanvas *c2 = new TCanvas("c2", "Depth", 1100,850);
    gStyle->SetOptTitle(1);
    gStyle->SetStatX(0.33);
    gStyle->SetStatY(0.87);
    altitude_hist->Draw("HIST");
    
    gStyle->SetHistLineWidth(9);
    c2->Print("Primaries/altitude_int.png");
    gStyle->SetHistLineWidth(2);
    c2->Print("Primaries/altitude_int.pdf");
    c2->Print("Primaries/altitude_int.root");
    

    //c3.Surface Distance of Interaction from Balloon Histogram (r_fromballoon)
    TCanvas *c3 = new TCanvas("c3","r_fromballoon", 1100,850);
    gStyle->SetOptTitle(1);
    gStyle->SetStatX(0.88);
    gStyle->SetStatY(0.88);
    r_fromballoon_hist->Draw("HIST");
    
    gStyle->SetHistLineWidth(9);
    c3->Print("Primaries/r_fromballoon.png");
    gStyle->SetHistLineWidth(2);
    c3->Print("Primaries/r_fromballoon.pdf");
    c3->Print("Primaries/r_fromballoon.root");
    
    
    //c4.Interacted Neutrino Flavors Histogram (nuflavorint)
    TCanvas *c4 = new TCanvas("c4", "nuflavorint", 1100,850);
    gStyle->SetOptTitle(1);
    gStyle->SetStatX(0.88);
    gStyle->SetStatY(0.87);
    nuflavorint_hist->Draw("HIST");
    
    gStyle->SetHistLineWidth(9);
    c4->Print("Primaries/nuflavorint.png");
    gStyle->SetHistLineWidth(2);
    c4->Print("Primaries/nuflavorint.pdf");
    c4->Print("Primaries/nuflavorint.root");
    
            
    //c5.Surface Distance Squared Histogram (r_fromballoon_sq)
    TCanvas *c5 = new TCanvas("c5","r_fromballoon_sq", 1100,850);
    gStyle->SetOptTitle(1);
    gStyle->SetStatX(0.88);
    gStyle->SetStatY(0.88);
    r_fromballoon_sq_hist->Draw("HIST");
    
    gStyle->SetHistLineWidth(9);
    c5->Print("Primaries/r_fromballoon_sq.png");
    gStyle->SetHistLineWidth(2);
    c5->Print("Primaries/r_fromballoon_sq.pdf");
    c5->Print("Primaries/r_fromballoon_sq.root");
    
    
    //c6.Surface Distance vs. Depth of Interaction Histogram
    TCanvas *c6 = new TCanvas("c6", "Surface_Dist vs Depth_Int",1550,1000);
    gStyle->SetOptTitle(1);
    gStyle->SetStatX(0.90);
    gStyle->SetStatY(0.36);
    r_fromballoon_vs_depth_int->Draw("colz");
    
    c6->SaveAs("Primaries/r_fromballoon_vs_altitude_int.png");
    c6->SaveAs("Primaries/r_fromballoon_vs_altitude_int.pdf");
    c6->SaveAs("Primaries/r_fromballoon_vs_altitude_int.root");
    
    
    //c7.Surface Distance Squared vs. Depth of Interaction Histogram
    TCanvas *c7 = new TCanvas("c7", "Surface_Dist_Sq vs Depth_Int",1550,1000);
    gStyle->SetOptTitle(1);
    gStyle->SetStatX(0.90);
    gStyle->SetStatY(0.36);
    r_fromballoon_sq_vs_depth_int->Draw("colz");
    
    gStyle->SetHistLineWidth(9);
    c7->SaveAs("Primaries/r_fromballoon_sq_vs_altitude_int.png");
    gStyle->SetHistLineWidth(2);
    c7->SaveAs("Primaries/r_fromballoon_sq_vs_altitude_int.pdf");
    c7->SaveAs("Primaries/r_fromballoon_sq_vs_altitude_int.root");
    
    
    //c8.Fresnel Coefficient at Air-Firn Interface Histogram (first result, fresnel1)
    TCanvas *c8 = new TCanvas("c8", "fresnel1",1100,850);
    gStyle->SetOptTitle(1);
    gStyle->SetStatX(0.33);
    gStyle->SetStatY(0.87);
    fresnel_1->Draw("HIST");
    
    gStyle->SetHistLineWidth(9);
    c8->Print("Primaries/fresnel1.png");
    gStyle->SetHistLineWidth(2);
    c8->Print("Primaries/fresnel1.pdf");
    c8->Print("Primaries/fresnel1.root");
    
    
    //c9.Fresnel Coefficient at Air-Firn Interface Histogram (second result, fresnel2)
    TCanvas *c9 = new TCanvas("c9", "fresnel2",1100,850);
    gStyle->SetOptTitle(1);
    gStyle->SetStatX(0.33);
    gStyle->SetStatY(0.87);
    fresnel_2->Draw("HIST");
    
    gStyle->SetHistLineWidth(9);
    c9->Print("Primaries/fresnel2.png");
    gStyle->SetHistLineWidth(2);
    c9->Print("Primaries/fresnel2.pdf");
    c9->Print("Primaries/fresnel2.root");
    
    //c10.The Charge of Neutrinos Histogram (currentint)
    TCanvas *c10 = new TCanvas("c10", "currentint", 1100,850);
    gStyle->SetOptTitle(1);
    gStyle->SetStatX(0.88);
    gStyle->SetStatY(0.87);
    currentint_hist->Draw("HIST");
    
    gStyle->SetHistLineWidth(9);
    c10->Print("Primaries/currentint.png");
    gStyle->SetHistLineWidth(2);
    c10->Print("Primaries/currentint.pdf");
    c10->Print("Primaries/currentint.root");
    
    
    //c11.Dtrying Direction Histogram (dtryingdirection)
    TCanvas *c11 = new TCanvas("c11", "dtryingdirection", 1100,850);
    gStyle->SetOptTitle(1);
    gStyle->SetStatX(0.88);
    gStyle->SetStatY(0.87);
    dtrying_hist->Draw("HIST");
    
    gStyle->SetHistLineWidth(9);
    c11->Print("Primaries/dtryingdirection.png");
    gStyle->SetHistLineWidth(2);
    c11->Print("Primaries/dtryingdirection.pdf");
    c11->Print("Primaries/dtryingdirection.root");
    
    
    //c12.The Traverse Chords of Neutrinos Histogram (chord_kgm2_bestcase)
    TCanvas *c12 = new TCanvas("c12", "chord_kgm2_bestcase", 1100,850);
    gStyle->SetOptTitle(1);
    gStyle->SetStatX(0.33);
    gStyle->SetStatY(0.88);
    chord_kgm2_bestcase_hist->Draw("HIST");
    
    gStyle->SetHistLineWidth(9);
    c12->Print("Primaries/chord_kgm2_bestcase.png");
    gStyle->SetHistLineWidth(2);
    c12->Print("Primaries/chord_kgm2_bestcase.pdf");
    c12->Print("Primaries/chord_kgm2_bestcase.root");
    
    //c13.Best Case Weight Histogram (weight_bestcase)
    TCanvas *c13 = new TCanvas("c13", "weight_bestcase", 1100,850);
    gStyle->SetOptTitle(1);
    gStyle->SetStatX(0.88);
    gStyle->SetStatY(0.88);
    weight_bestcase_hist->Draw("HIST");
    
    gStyle->SetHistLineWidth(9);
    c13->Print("Primaries/weight_bestcase.png");
    gStyle->SetHistLineWidth(2);
    c13->Print("Primaries/weight_bestcase.pdf");
    c13->Print("Primaries/weight_bestcase.root");
    
    //c14.Log of Chord Length (logchord)
    TCanvas *c14 = new TCanvas("c14", "logchord", 1100,850);
    gStyle->SetOptTitle(1);
    gStyle->SetStatX(0.33);
    gStyle->SetStatY(0.88);
    logchord_hist->Draw("HIST");
    
    gStyle->SetHistLineWidth(9);
    c14->Print("Primaries/logchord.png");
    gStyle->SetHistLineWidth(2);
    c14->Print("Primaries/logchord.pdf");
    c14->Print("Primaries/logchord.root");
    
    //c15. Surface Distance of Neurtino When Exiting Balloon Histogram (r_exit2bn)
    TCanvas *c15 = new TCanvas("c15","r_exit2bn", 1100,850);
    gStyle->SetOptTitle(1);
    gStyle->SetStatX(0.88);
    gStyle->SetStatY(0.88);
    r_exit2bn_hist->Draw("HIST");
    
    gStyle->SetHistLineWidth(9);
    c15->Print("Primaries/r_exit2bn.png");
    gStyle->SetHistLineWidth(2);
    c15->Print("Primaries/r_exit2bn.pdf");
    c15->Print("Primaries/r_exit2bn.root");
    
    //c16.Measured Surface Distance of Neurtino When Exiting Balloon Histogram (r_exit2bn_measured)
    TCanvas *c16 = new TCanvas("c16", "r_exit2bn_measured", 1100,850);
    gStyle->SetOptTitle(1);
    gStyle->SetStatX(0.88);
    gStyle->SetStatY(0.88);
    r_exit2bn_measured_hist->Draw("HIST");
    
    gStyle->SetHistLineWidth(9);
    c16->Print("Primaries/r_exit2bn_measured.png");
    gStyle->SetHistLineWidth(2);
    c16->Print("Primaries/r_exit2bn_measured.pdf");
    c16->Print("Primaries/r_exit2bn_measured.root");
    
    //c17.Exit Earth Histogram (nuexit)
    TCanvas *c17 = new TCanvas("c17","nuexitlength (magnitude)", 1500,1000);
    gStyle->SetOptTitle(1);
    gStyle->SetStatX(0.88);
    gStyle->SetStatY(0.88);
    nuexit_hist->Draw("HIST");
    
    gStyle->SetHistLineWidth(9);
    c17->Print("Primaries/nuexit.png");
    gStyle->SetHistLineWidth(2);
    c17->Print("Primaries/nuexit.pdf");
    c17->Print("Primaries/nuexit.root");
    
    //c18.Exit Ice Histogram (nuexitice)
    TCanvas *c18 = new TCanvas("c18", "nuexitice", 1500,1000);
    gStyle->SetOptTitle(1);
    gStyle->SetStatX(0.89);
    gStyle->SetStatY(0.88);
    nuexitice_hist->Draw("HIST");
    
    gStyle->SetHistLineWidth(9);
    c18->Print("Primaries/nuexitice.png");
    gStyle->SetHistLineWidth(2);
    c18->Print("Primaries/nuexitice.pdf");
    c18->Print("Primaries/nuexitice.root");
    
    //c19.Interaction Angles->Costheta Histogram (costheta_nutraject)
    TCanvas *c19 = new TCanvas("c19", "costheta_nutraject", 1100,850);
    gStyle->SetOptTitle(1);
    gStyle->SetStatX(0.33);
    gStyle->SetStatY(0.88);
    costheta_nutraject_hist->Draw("HIST");
    
    gStyle->SetHistLineWidth(9);
    c19->Print("Primaries/costheta_nutraject.png");
    gStyle->SetHistLineWidth(2);
    c19->Print("Primaries/costheta_nutraject.pdf");
    c19->Print("Primaries/costheta_nutraject.root");
    
    //c20.Earth Entrance to rock-ice boundary Histogram (d1)
    TCanvas *c20 = new TCanvas("c20", "d1", 1100,850);
    gStyle->SetOptTitle(1);
    gStyle->SetStatX(0.88);
    gStyle->SetStatY(0.88);
    d1_hist->Draw("HIST");
    
    gStyle->SetHistLineWidth(9);
    c20->Print("Primaries/d1.png");
    gStyle->SetHistLineWidth(2);
    c20->Print("Primaries/d1.pdf");
    c20->Print("Primaries/d1.root");
    
    //c21.Ice-rock Boundary to Interaction Point Histogram (d2)
    TCanvas *c21 = new TCanvas("c21", "d2", 1100,850);
    gStyle->SetOptTitle(1);
    gStyle->SetStatX(0.33);
    gStyle->SetStatY(0.88);
    d2_hist->Draw("HIST");
    
    gStyle->SetHistLineWidth(9);
    c21->Print("Primaries/d2.png");
    gStyle->SetHistLineWidth(2);
    c21->Print("Primaries/d2.pdf");
    c21->Print("Primaries/d2.root");
    
    //c22.Earth Entrance to Interaction Point Histogram (d1+d2)
    TCanvas *c22 = new TCanvas("c22", "d1+d2", 1100,850);
    gStyle->SetOptTitle(1);
    gStyle->SetStatX(0.88);
    gStyle->SetStatY(0.88);
    d1plusd2_hist->Draw("HIST");
    
    gStyle->SetHistLineWidth(9);
    c22->Print("Primaries/d1+d2.png");
    gStyle->SetHistLineWidth(2);
    c22->Print("Primaries/d1+d2.pdf");
    c22->Print("Primaries/d1+d2.root");
    
    //c23. Direction of Neutrinos (nnu) (+z in south pole direction)
    // TCanvas *c23 = new TCanvas("c23","nnu",1100,850);
    // gStyle->SetOptTitle(1);
    // gStyle->SetStatX(0.90);
    // gStyle->SetStatY(0.90);
    // nnu_hist->Draw("colz");
    
    // gStyle->SetHistLineWidth(9);
    // c23->Print("Primaries/nnu.png");
    // gStyle->SetHistLineWidth(2);
    // c23->Print("Primaries/nnu.pdf");
    // c23->Print("Primaries/nnu.root");
    
    //c26.Theta_Nutraject in Degrees Histogram (theta)
    TCanvas *c26 = new TCanvas("c26","theta",1100,850);
    gStyle->SetOptTitle(1);
    gStyle->SetStatX(0.33);
    gStyle->SetStatY(0.88);
    theta_hist->Draw("HIST");
    
    gStyle->SetHistLineWidth(9);
    c26->Print("Primaries/theta.png");
    gStyle->SetHistLineWidth(2);
    c26->Print("Primaries/theta.pdf");
    c26->Print("Primaries/theta.root");
    
    //c27.Position where Neutrino Enters the Earth Histogram (r_in)
    TCanvas *c27 = new TCanvas("c27", "r_in", 1100, 850);
    gStyle->SetOptTitle(1);
    gStyle->SetStatX(0.88);
    gStyle->SetStatY(0.88);
    r_in_hist->Draw("HIST");
    
    gStyle->SetHistLineWidth(9);
    c27->Print("Primaries/r_in.png");
    gStyle->SetHistLineWidth(2);
    c27->Print("Primaries/r_in.pdf");
    c27->Print("Primaries/r_in.root");
    
    //c28.Position where Neutrino Enters the Ice Histogram (r_enterice)
    TCanvas *c28 = new TCanvas("c28", "r_enterice", 1100, 850);
    gStyle->SetOptTitle(1);
    gStyle->SetStatX(0.33);
    gStyle->SetStatY(0.88);
    r_enterice_hist->Draw("HIST");
    
    gStyle->SetHistLineWidth(9);
    c28->Print("Primaries/r_enterice.png");
    gStyle->SetHistLineWidth(2);
    c28->Print("Primaries/r_enterice.pdf");
    c28->Print("Primaries/r_enterice.root");
    
    //c29.Chord from Earth Entrance to Rock-Ice Boundary Histogram (chord)
    TCanvas *c29 = new TCanvas("c29", "chord", 1100, 850);
    gStyle->SetOptTitle(1);
    gStyle->SetStatX(0.88);
    gStyle->SetStatY(0.88);
    chord_hist->Draw("HIST");
    
    gStyle->SetHistLineWidth(9);
    c29->Print("Primaries/chord.png");
    gStyle->SetHistLineWidth(2);
    c29->Print("Primaries/chord.pdf");
    c29->Print("Primaries/chord.root");
    
    //c30.Deviation from the Cerenkov Angle Histogram (dviewangle_deg)
    TCanvas *c30 = new TCanvas("c30", "dviewangle_deg", 1100, 850);
    gStyle->SetOptTitle(1);
    gStyle->SetStatX(0.88);
    gStyle->SetStatY(0.88);
    dviewangle_deg_hist->Draw("HIST");
    
    gStyle->SetHistLineWidth(9);
    c30->Print("Primaries/deviewangle_deg.png");
    gStyle->SetHistLineWidth(2);
    c30->Print("Primaries/deviewangle_deg.pdf");
    c30->Print("Primaries/deviewangle_deg.root");
    
    //c31.Phi Angle of the Ray from the Surface to the Balloon Histogram (n_exit_phi)
    TCanvas *c31 = new TCanvas("c31", "n_exit_phi", 1100, 850);
    gStyle->SetOptTitle(1);
    gStyle->SetStatX(0.60);
    gStyle->SetStatY(0.90);
    n_exit_phi_hist->Draw("HIST");
    
    gStyle->SetHistLineWidth(9);
    c31->Print("Primaries/n_exit_phi.png");
    gStyle->SetHistLineWidth(2);
    c31->Print("Primaries/n_exit_phi.pdf");
    c31->Print("Primaries/n_exit_phi.root");
    
    //c32.Mytheta Histogram (mytheta)
    TCanvas *c32 = new TCanvas("c32", "mytheta",1100,850);
    gStyle->SetOptTitle(1);
    gStyle->SetStatX(0.88);
    gStyle->SetStatY(0.88);
    mytheta_hist->Draw("HIST");
    
    gStyle->SetHistLineWidth(9);
    c32->Print("Primaries/mytheta.png");
    gStyle->SetHistLineWidth(2);
    c32->Print("Primaries/mytheta.pdf");
    c32->Print("Primaries/mytheta.root");
    
    //c33.Mybeta Histogram (mybeta)
    TCanvas *c33 = new TCanvas("c33", "mybeta",1100,850);
    gStyle->SetOptTitle(1);
    gStyle->SetStatX(0.33);
    gStyle->SetStatY(0.88);
    mybeta_hist->Draw("HIST");
    
    gStyle->SetHistLineWidth(9);
    c33->Print("Primaries/mybeta.png");
    gStyle->SetHistLineWidth(2);
    c33->Print("Primaries/mybeta.pdf");
    c33->Print("Primaries/mybeta.root");
    
    //c34.Polar Angle of the Signal at the Balloon Histogram (theta_rf_atbn)
    TCanvas *c34 = new TCanvas("c34", "theta_rf_atbn", 1100, 850);
    gStyle->SetOptTitle(1);
    gStyle->SetStatX(0.33);
    gStyle->SetStatY(0.88);
    theta_rf_atbn_hist->Draw("HIST");
    
    gStyle->SetHistLineWidth(9);
    c34->Print("Primaries/theta_rf_atbn.png");
    gStyle->SetHistLineWidth(2);
    c34->Print("Primaries/theta_rf_atbn.pdf");
    c34->Print("Primaries/theta_rf_atbn.root");
    
    //c35.NNU Cos(Theta) and Phi Histograms (nnucostheta, nnuphi)
    TCanvas *c35 = new TCanvas("c35", "NNU Graphs", 2200, 850);
    c35->Divide(2);
    c35->cd(1);
    gStyle->SetOptTitle(1);
    gStyle->SetStatX(0.10);
    gStyle->SetStatY(0.90);
    nnucostheta_hist->Draw("HIST");
    c35->cd(2);
    gStyle->SetOptTitle(1);
    gStyle->SetStatX(0.97);
    gStyle->SetStatY(0.97);
    nnuphi_hist->Draw("HIST");
    
    gStyle->SetHistLineWidth(9);
    c35->Print("Primaries/nnu_costheta_cosphi.png");
    gStyle->SetHistLineWidth(2);
    c35->Print("Primaries/nnu_costheta_cosphi.pdf");
    c35->Print("Primaries/nnu_costheta_cosphi.root");
    
    //c36.Cos(Theta) and Phi of Position where Neutrino Enters the Earth Histogram (rincostheta, rinph)
    TCanvas *c36 = new TCanvas("c36", "r_in cos(theta) and Phi", 2200, 850);
    c36->Divide(2);
    c36->cd(1);
    c36->cd(2);
    
    c36->cd(1);
    gStyle->SetOptTitle(1);
    gStyle->SetStatX(0.20);
    gStyle->SetStatY(0.88);
    rincostheta_hist->Draw("HIST");
    
    c36->cd(2);
    gStyle->SetOptTitle(1);
    gStyle->SetStatX(0.55);
    gStyle->SetStatY(0.88);
    rinphi_hist->Draw("HIST");
    
    gStyle->SetHistLineWidth(9);
    c36->Print("Primaries/rin_costheta_phi.png");
    gStyle->SetHistLineWidth(2);
    c36->Print("Primaries/rin_costheta_phi.pdf");
    c36->Print("Primaries/rin_costheta_phi.root");
    
    //Theta vs Phi Histogram (theta,phi); The plot does not look good since phi is too small;
    /*
     TCanvas *c38 = new TCanvas("c38", "theta_vs_phi",1100,850);
    gStyle->SetOptTitle(1);
    gStyle->SetStatX(0.88);
    gStyle->SetStatY(0.88);
    theta_vs_phi_hist->Draw("colz");
    
    gStyle->SetHistLineWidth(9);
    c38->SaveAs("Primaries/theta_vs_phi.png");
    gStyle->SetHistLineWidth(1);
    c38->SaveAs("Primaries/theta_vs_phi.pdf");
    c38->SaveAs("Primaries/theta_vs_phi.root");
    */
    
    //Save Plots
    
    return 0;
    
}
    
    
    
    
    
    
