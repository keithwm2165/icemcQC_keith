//
//
// Author: Victoria Niu
// Created Time: April 2020
//
//
// REVISED FROM THE SCRIPTS WRITTEN BY NATALIE KEYES (MAY 2016)
//
// C++&Canvas Heading
#include <iostream>
#include <fstream>
#include <sstream>
#include <math.h>
#include <string>
#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <time.h>
#include "TTreeIndex.h"
#include "TChain.h"
#include "TH1.h"
#include "TF1.h"
#include "TF2.h"
#include "TFile.h"
#include "TRandom.h"
#include "TRandom2.h"
#include "TRandom3.h"
#include "TTree.h"
#include "TLegend.h"
#include "TLine.h"
#include "TROOT.h"
#include "TPostScript.h"
#include "TCanvas.h"
#include "TH2F.h"
#include "TText.h"
#include "TProfile.h"
#include "TGraphErrors.h"
#include "TStyle.h"
#include "TMath.h"
#include <unistd.h>
#include "TVector3.h"
#include "TRotation.h"
#include "TSpline.h"
#include "Math/InterpolationTypes.h"
#include "Math/Interpolator.h"
#include "signal.h"
#include "icemc_random.h"
#include <string>

#include "TGaxis.h"
#include "TPaveStats.h"

// Icemc Headings
#include "Constants.h"
#include "Settings.h"
#include "position.hh"
#include "earthmodel.hh"
#include "Tools.h"
#include "vector.hh"
#include "roughness.hh"
#include "anita.hh"
#include "balloon.hh"
#include "icemodel.hh"
// #include "trigger.hh"
#include "Spectra.h"
#include "signal.hh"
#include "secondaries.hh"
#include "ray.hh"
#include "counting.hh"
#include "Primaries.h"
#include "Taumodel.hh"

using namespace std;

int NNU;
double RANDOMISEPOL;

////////////////PLOTTING SCRIPT FOR ICEMCQC WRITTEN BY VICTORIA NIU IN APIRL 2020, REVISED FROM THE SCRIPTS WRITTEN BY NATALIE KEYES (MAY 2016) AND PREVIOUS QC GROUP ///////////////////////////////

// defline unpackbit function
void unpackbits(int n, TH1F *hist, int x, int y)
{
  for(int i=0; i<x; i++) 
    {
      int mask =  1 << i;
      int masked_n = n & mask;
      int thebit = masked_n >> i;
      if(thebit==1) { hist->Fill(i+y); }
    }
}


int main(int argc, char *argv[])
{
    gStyle->SetOptStat(1111);     // Setup Statistics;
    
    gStyle->SetFrameFillStyle (2);
    gStyle->SetFrameFillColor (0);
    gStyle->SetFrameLineColor (1);
    gStyle->SetFrameLineStyle (0);
    gStyle->SetFrameLineWidth (2.5);
    gStyle->SetFrameBorderSize(10);
    gStyle->SetFrameBorderMode(0);
    gStyle->SetHistLineWidth(2.5);
    gStyle->SetTitleFontSize(0.05);
    
    /*gStyle->SetHistFillColor(0);
     gStyle->SetHistFillStyle(1);
     gStyle->SetHistLineColor(1);
     gStyle->SetHistLineStyle(0);
     gStyle->SetHistLineWidth(3);       //Setup plot Style */
    
	if(argc<2)
	  {
	    cout << "Not enough arguments! Stop run. " << endl;
	  }
    
	TH1F *triggers_hist_array[48];
    TH1F *triggers_hist = new TH1F("triggers_hist", "triggers histogram",100,-1,10);
    TH1F *nchannels_triggered_hist = new TH1F("nchannels_triggered_hist", "nchannels_triggered histogram",100,100,200);
    
    TH1F *l3trig_hist = new TH1F("l3trig_hist", "l3trig histogram", 25,-5,20);
    TH1F *l2trig_hist_1 = new TH1F("l2trig_hist_1", "l2trig histogram #1", 60,-5,55);
    TH1F *l2trig_hist_2 = new TH1F("l2trig_hist_2", "l2trig histogram #2", 60,-5,55);
    TH1F *l2trig_hist_3 = new TH1F("l2trig_hist_3", "l2trig histogram #3", 60,-5,55);
    TH1F *l1trig_hist_1 = new TH1F("l1trig_hist_1", "l1trig histogram #1", 60,-5,55);
    TH1F *l1trig_hist_2 = new TH1F("l1trig_hist_2", "l1trig histogram #2", 60,-5,55);
    TH1F *l1trig_hist_3 = new TH1F("l1trig_hist_3", "l1trig histogram #3", 60,-5,55);
    TH1F *eventsfound_beforetrigger_hist = new TH1F("eventsfound_beforetrigger_hist", "eventsfound_beforetrigger histogram", 100,-10,10);
    
    for(int i=1; i < argc; i++)
    {   // loop over the input files
        
        string readfile = string(argv[i]);
        TFile *AnitaFile = new TFile(( readfile ).c_str());
        cout << "AnitaFile" << endl;
        // get all trees from AnitaFile
        TTree *passing_events= (TTree*)AnitaFile->Get("passing_events");
        TTree *summarytree = (TTree*)AnitaFile->Get("summarytree");
        cout << "Reading AnitaFile..." << endl;
        cout << "num: " << readfile << endl;
        
        
        //Define Variables
        int num_pass;                   //number of passing events
        double weight;                  //weight of passing events
        const int num_antennae=48;       //number of anteenae channels we want to plot
        
        // trigger class variables
        int triggers[num_antennae];      // trigger channel (plot the first 5)
        int nchannels_triggered;         // the number of trigger channels
        int l3trig;
        int l2trig[3];
        int l1trig[3];
        double eventsfound_beforetrigger;
        
        // balloon class variables
        double heading, pitch, roll, latitude, longitude, altitude, horizcoord_bn, vertcoord_bn;
        unsigned int realTime_flightdata;
        
        // the passing_events number
        num_pass = passing_events->GetEntries();
        cout << "num_pass is " << num_pass << endl;
        double weight_array[num_pass];
        
        // set branch addresses
        passing_events->SetBranchAddress("triggers", &triggers);
        passing_events->SetBranchAddress("nchannels_triggered", &nchannels_triggered);
        passing_events->SetBranchAddress("l3trig", &l3trig);
        passing_events->SetBranchAddress("l2trig", &l2trig);
        passing_events->SetBranchAddress("l1trig", &l1trig);
        summarytree->SetBranchAddress("eventsfound_beforetrigger",&eventsfound_beforetrigger);
        
        // array of triggers histograms for each of 5 antennae
        for(int j=0; j<num_antennae; j++)
        {
            int a = j+1;
            stringstream ss;
            ss << a;
            string s = ss.str();
            string hist_id = "triggers_hist" + s;
            string hist_name = "triggers histogram for antenna #" + s;
            triggers_hist_array[j] = new TH1F(hist_id.c_str(), hist_name.c_str(), 100,-1,10);
        }
        
       for (int k=0; k<num_pass; k++)
        {
            cout << "*";
            if((k+1) % 100 == 0) { cout << endl << k+1 << endl; }
            passing_events->GetEvent(k);
            
            for(int m=0; m<num_antennae; i++)
            {
                triggers_hist->Fill(triggers[m]);  // triggers (1 histogram)
                triggers_hist_array[m]->Fill(triggers[m]);  // triggers (48 histograms - 1/channel)
            }
            
            nchannels_triggered_hist->Fill(nchannels_triggered); // nchannels_triggered
            eventsfound_beforetrigger_hist->Fill(eventsfound_beforetrigger); // eventsfound_beforetrigger
            
            unpackbits(l3trig, l3trig_hist, 16,0); // l3trig (1 histogram for number of triggering events for each phi sector)
            
            unpackbits(l2trig[0], l2trig_hist_1, 16,0); // l2trig upper ring
            unpackbits(l2trig[1], l2trig_hist_2, 16,16); // l2trig lower ring
            unpackbits(l2trig[1], l2trig_hist_3, 8,32); // l2trig nadir ring
            
            unpackbits(l1trig[0], l1trig_hist_1, 16,0); // l1trig upper ring
            unpackbits(l1trig[1], l1trig_hist_2, 16,16); // 11trig lower ring
            unpackbits(l1trig[1], l1trig_hist_3, 8,32); // l1trig nadir ring
            
        }   // CLOSE FOR LOOP OVER NUMBER OF EVENTS
        
    }  // CLOSE FOR LOOP OVER NUMBER OF INPUT FILES
    
    //  Make Histograms
	TCanvas *test_canvas = new TCanvas("test_canvas", "test canvas", 1100, 850);
	for(int x=0; x<40; x++)
	  {
	    int a = x+1;
	    stringstream ss;
	    ss << a;
	    string s = ss.str();  // convert index to string so plots will be labeled by channel number
	    TH1F *hist = triggers_hist_array[x];   // get current histogram
	    hist->Draw();                     // plot
	    hist->GetXaxis()->SetTitle("weighted number of channels triggered");
	    hist->GetYaxis()->SetTitle("weighted Number of Events");
	    hist->GetYaxis()->SetTitleOffset(1.5);
	    string png = "triggerplots/triggers" + s + ".png";       // make filenames
 	    string root = "triggerplots/triggers" + s + ".root"; 
	    string pdf = "triggerplots/triggers" + s + ".pdf";
	    test_canvas->Print(png.c_str());                 // print
	    test_canvas->Print(root.c_str());
	    test_canvas->Print(pdf.c_str());
	  }

	cout << "Drew 48 triggers plots" << endl;


	// plot triggers (single histogram, for all channels)
	TCanvas *c1 = new TCanvas("c1", "triggers", 1100, 850);
	triggers_hist->Draw();
	triggers_hist->GetXaxis()->SetTitle("number of channels triggered");
	triggers_hist->GetYaxis()->SetTitle("Number of Events");
	triggers_hist->GetYaxis()->SetTitleOffset(1.5);
	c1->Print("triggerplots/triggers.png");
	c1->Print("triggerplots/triggers.root");
	c1->Print("triggerplots/triggers.pdf");

	cout << "Drew triggers plot" << endl;


	// plot nchannels_triggered
	TCanvas *c2 = new TCanvas("c2", "nchannels_triggered", 1100, 850);
	nchannels_triggered_hist->Draw();
	nchannels_triggered_hist->GetXaxis()->SetTitle("number of channels triggered");
	nchannels_triggered_hist->GetYaxis()->SetTitle("Number of Events");
	nchannels_triggered_hist->GetYaxis()->SetTitleOffset(1.5);
	c2->Print("triggerplots/nchannels_triggered.png");
	c2->Print("triggerplots/nchannels_triggered.root");
	c2->Print("triggerplots/nchannels_triggered.pdf");

	cout << "Drew nchannels_triggered plot" << endl;

	
	// plot eventsfound_beforetrigger
	TCanvas *c3 = new TCanvas("c3", "eventsfound_beforetrigger", 1100, 850);
	eventsfound_beforetrigger_hist->Draw();
	eventsfound_beforetrigger_hist->GetXaxis()->SetTitle("number of events found before the trigger");
	eventsfound_beforetrigger_hist->GetYaxis()->SetTitle("Number of Events (weighted)");
	eventsfound_beforetrigger_hist->GetYaxis()->SetTitleOffset(1.5);
	c3->Print("triggerplots/eventsfound_beforetrigger.png");
	c3->Print("triggerplots/eventsfound_beforetrigger.root");
	c3->Print("triggerplots/eventsfound_beforetrigger.pdf");

	cout << "Drew eventsfound_beforetrigger plot" << endl;


	// plot l3trig
	TCanvas *c4 = new TCanvas("c4", "l3trig", 1100, 850);
	l3trig_hist->Draw();
	l3trig_hist->GetXaxis()->SetTitle("phi sector number");
	l3trig_hist->GetYaxis()->SetTitle("Number of Events triggering phi sector");
	l3trig_hist->GetYaxis()->SetTitleOffset(1.5);
	c4->Print("triggerplots/l3trig.png");
	c4->Print("triggerplots/l3trig.root");
	c4->Print("triggerplots/l3trig.pdf");

	cout << "Drew l3trig plot" << endl;


	// plot l2trig - combination of 3 rings' plots
	TCanvas *c5 = new TCanvas("c5", "l2trig", 1100, 850);
	l2trig_hist_1->Draw();
	l2trig_hist_1->SetLineColor(kRed);
	l2trig_hist_1->GetXaxis()->SetTitle("antenna number");
	l2trig_hist_1->GetYaxis()->SetTitle("number of triggering events");
	l2trig_hist_1->GetYaxis()->SetTitleOffset(1.5);
	l2trig_hist_2->Draw("same");
	l2trig_hist_2->SetLineColor(kBlue);
	l2trig_hist_3->Draw("same");
	l2trig_hist_3->SetLineColor(kGreen);
	c5->Update();
	c5->Print("triggerplots/l2trig.png");
	c5->Print("triggerplots/l2trig.root");
	c5->Print("triggerplots/l2trig.pdf");

	cout << "Drew l2trig plot" << endl;

	
	// plot l1trig - combination of 3 rings' plots
	TCanvas *c6 = new TCanvas("c6", "l1trig", 1100, 850);
	l1trig_hist_1->Draw();
	l1trig_hist_1->SetLineColor(kRed);
	l1trig_hist_1->GetXaxis()->SetTitle("antenna number");
	l1trig_hist_1->GetYaxis()->SetTitle("number of triggering events");
	l1trig_hist_1->GetYaxis()->SetTitleOffset(1.5);
	l1trig_hist_2->Draw("same");
	l1trig_hist_2->SetLineColor(kBlue);
	l1trig_hist_3->Draw("same");
	l1trig_hist_3->SetLineColor(kGreen);
	c6->Update();
	c6->Print("triggerplots/l1trig.png");
	c6->Print("triggerplots/l1trig.root");
	c6->Print("triggerplots/l1trig.pdf");

	cout << "Drew l1trig plot" << endl;
    
    return 0;

}
