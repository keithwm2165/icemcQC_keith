#PBS -N run_icemc
#PBS -A PAS0654
#PBS -l walltime=2:00:00
#PBS -l nodes=1:ppn=1
#PBS -l mem=1GB

cd $PBS_O_WORKDIR
echo $PBS_O_WORKDIR

echo 'output file: '$OUTDIR
echo 'energy level: '$ENERGY

# energy e21
./icemc -i $INPUTFILE -o $OUTDIR -r $RUN_NO -n 2000000 -e $ENERGY
pbsdcp /tmp/icefinal$RUN_NO/'*' $OUTDIR
