#!/bin/bash

# QC submit icemc jobs
#
# Created by Victoria Niu (niu.172@osu.edu) in Nov 2019
#
# Adapted from the first version of Khalida Hendricks' IcemcQCSubmit.sh
#
# The program check the output directories for running icemc and submit run_icemc.sh jobs to OSC
#
# first make and clean make
# make clean
# make

# input and energy (change here to run different inputs)
ENG="$@"
IN_FILE=inputs.anita3.conf
OUTPUTDIR=output_anita3_e$ENG

if [ -d "$OUTPUTDIR" ]
then
    echo $OUTPUTDIR already exist
    rm -r $OUTPUTDIR
    mkdir $OUTPUTDIR
else
    mkdir $OUTPUTDIR
fi

# run numbers
count=1
run_num=5

while [ $count -le $run_num ]
do
    qsub -v INPUTFILE=$IN_FILE,OUTDIR=$OUTPUTDIR,RUN_NO=$count,ENERGY=$ENG run_icemc.sh
    ((count++))
done

echo submitted icemc jobs of energy $ENG
